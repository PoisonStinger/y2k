package com.cyberplay.music

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale
import kotlin.concurrent.thread

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private val songs = mutableListOf<Song>()
    private var visibleSongs = listOf<Song>()
    private var favoritesOnly = false
    private val favorites = mutableSetOf<Long>()
    private var repeatMode = Player.REPEAT_MODE_OFF
    private lateinit var songList: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var searchBox: EditText
    private lateinit var currentTitle: TextView
    private lateinit var currentArtist: TextView
    private lateinit var coverArt: ImageView
    private lateinit var seekBar: SeekBar
    private lateinit var currentTime: TextView
    private lateinit var totalTime: TextView
    private lateinit var playButton: Button
    private lateinit var shuffleButton: Button
    private lateinit var repeatButton: Button
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) scanSongs() else {
            emptyText.text = "Audio permission is needed to show songs stored on your phone."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        songList = findViewById(R.id.songList)
        emptyText = findViewById(R.id.emptyText)
        searchBox = findViewById(R.id.searchBox)
        currentTitle = findViewById(R.id.currentTitle)
        currentArtist = findViewById(R.id.currentArtist)
        coverArt = findViewById(R.id.coverArt)
        seekBar = findViewById(R.id.seekBar)
        currentTime = findViewById(R.id.currentTime)
        totalTime = findViewById(R.id.totalTime)
        playButton = findViewById(R.id.playButton)
        shuffleButton = findViewById(R.id.shuffleButton)
        repeatButton = findViewById(R.id.repeatButton)

        val prefs = getSharedPreferences("cyberplay", MODE_PRIVATE)
        favorites.addAll(prefs.getStringSet("favorites", emptySet())!!.mapNotNull { it.toLongOrNull() })
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { updateNowPlaying() }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playButton.text = if (isPlaying) "❚❚ PAUSE" else "▶ PLAY" }
            override fun onPlaybackStateChanged(playbackState: Int) { updateNowPlaying() }
        })

        findViewById<Button>(R.id.refreshButton).setOnClickListener { scanSongs() }
        findViewById<Button>(R.id.favoritesButton).setOnClickListener {
            favoritesOnly = !favoritesOnly
            findViewById<Button>(R.id.favoritesButton).text = if (favoritesOnly) "♥ FAVS" else "♡ FAVS"
            renderSongs()
        }
        playButton.setOnClickListener {
            if (player.mediaItemCount == 0 && visibleSongs.isNotEmpty()) playSong(visibleSongs.first())
            else if (player.isPlaying) player.pause() else player.play()
        }
        findViewById<Button>(R.id.previousButton).setOnClickListener { if (player.mediaItemCount > 0) player.seekToPreviousMediaItem() }
        findViewById<Button>(R.id.nextButton).setOnClickListener { if (player.mediaItemCount > 0) player.seekToNextMediaItem() }
        shuffleButton.setOnClickListener {
            player.shuffleModeEnabled = !player.shuffleModeEnabled
            shuffleButton.text = if (player.shuffleModeEnabled) "SHUF ✓" else "SHUF"
        }
        repeatButton.setOnClickListener {
            repeatMode = when (repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
            player.repeatMode = repeatMode
            repeatButton.text = when (repeatMode) {
                Player.REPEAT_MODE_ALL -> "REP ALL"
                Player.REPEAT_MODE_ONE -> "REP ONE"
                else -> "REP OFF"
            }
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderSongs() }
            override fun afterTextChanged(s: Editable?) {}
        })
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && player.duration > 0) currentTime.text = time(progress.toLong())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { if (player.duration > 0) player.seekTo(sb?.progress?.toLong() ?: 0L) }
        })
        if (hasAudioPermission()) scanSongs() else permissionLauncher.launch(audioPermission())
        window.decorView.post(object : Runnable {
            override fun run() {
                if (!isFinishing) {
                    if (player.duration > 0) {
                        seekBar.max = player.duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                        seekBar.progress = player.currentPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                        currentTime.text = time(player.currentPosition)
                        totalTime.text = time(player.duration)
                    }
                    window.decorView.postDelayed(this, 500)
                }
            }
        })
    }

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, audioPermission()) == PackageManager.PERMISSION_GRANTED

    private fun scanSongs() {
        if (!hasAudioPermission()) { permissionLauncher.launch(audioPermission()); return }
        songs.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Unknown track"
                    val artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown artist"
                    val duration = cursor.getLong(durationCol)
                    songs.add(Song(id, title, artist, ContentUris.withAppendedId(collection, id), duration))
                }
            }
            emptyText.visibility = if (songs.isEmpty()) View.VISIBLE else View.GONE
            if (songs.isEmpty()) emptyText.text = "No indexed songs found. Try tapping SCAN or check Music / Downloads."
            renderSongs()
        } catch (e: Exception) {
            emptyText.visibility = View.VISIBLE
            emptyText.text = "Couldn't scan audio files: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun renderSongs() {
        songList.removeAllViews()
        val query = searchBox.text.toString().trim().lowercase(Locale.getDefault())
        visibleSongs = songs.filter {
            (!favoritesOnly || favorites.contains(it.id)) &&
            (query.isEmpty() || it.title.lowercase(Locale.getDefault()).contains(query) ||
                    it.artist.lowercase(Locale.getDefault()).contains(query))
        }
        if (visibleSongs.isEmpty() && songs.isNotEmpty()) {
            emptyText.visibility = View.VISIBLE
            emptyText.text = if (favoritesOnly) "No favorites yet — tap ♡ beside a song." else "No tracks match that search."
        } else if (songs.isNotEmpty()) emptyText.visibility = View.GONE

        visibleSongs.forEach { song ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 9, 6, 9)
                setBackgroundColor(0xFF191E2B.toInt())
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val title = TextView(this).apply {
                text = "♫  ${song.title}"
                setTextColor(0xFFF4F7FF.toInt()); textSize = 15f; maxLines = 1
            }
            val artist = TextView(this).apply {
                text = "${song.artist}  •  ${time(song.duration)}"
                setTextColor(0xFFA8B2C8.toInt()); textSize = 12f; setPadding(0, 4, 0, 0); maxLines = 1
            }
            info.addView(title); info.addView(artist)
            row.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val fav = TextView(this).apply {
                text = if (favorites.contains(song.id)) "♥" else "♡"
                textSize = 25f; setTextColor(0xFFFF71D8.toInt()); setPadding(10, 2, 10, 2)
                setOnClickListener {
                    if (!favorites.add(song.id)) favorites.remove(song.id)
                    getSharedPreferences("cyberplay", MODE_PRIVATE).edit()
                        .putStringSet("favorites", favorites.map { it.toString() }.toSet()).apply()
                    renderSongs()
                }
            }
            row.addView(fav)
            row.setOnClickListener { playSong(song) }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 5
            songList.addView(row, lp)
        }
    }

    private fun playSong(song: Song) {
        val queue = visibleSongs.ifEmpty { songs }
        val index = queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        player.setMediaItems(queue.map { MediaItem.fromUri(it.uri) }, index, 0L)
        player.prepare()
        player.play()
        updateNowPlaying()
    }

    private fun updateNowPlaying() {
        val index = player.currentMediaItemIndex
        val song = if (index >= 0 && index < visibleSongs.size) visibleSongs[index]
                   else songs.firstOrNull { it.uri.toString() == player.currentMediaItem?.localConfiguration?.uri.toString() }
        if (song != null) {
            currentTitle.text = song.title
            currentArtist.text = song.artist
            totalTime.text = time(song.duration)
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(this, song.uri)
                val bytes = retriever.embeddedPicture
                if (bytes != null) coverArt.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
                else coverArt.setImageResource(R.drawable.album_placeholder)
                retriever.release()
            } catch (_: Exception) { coverArt.setImageResource(R.drawable.album_placeholder) }
        }
    }

    private fun time(ms: Long): String {
        if (ms < 0 || ms == Long.MIN_VALUE) return "0:00"
        val sec = ms / 1000
        return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60)
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
