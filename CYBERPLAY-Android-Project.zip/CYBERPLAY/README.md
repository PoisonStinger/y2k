# CYBERPLAY — Chrome Y2K Android Music Player

A starter Android Studio project for playing locally indexed audio files on your Android phone. It includes a chrome/neon-inspired dark UI, local song scan, search, favorites, embedded album art when available, play/pause, previous/next, seek bar, shuffle and repeat.

## Build and install
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Extract `CYBERPLAY-Android-Project.zip`.
3. In Android Studio choose **Open** and select the extracted `CYBERPLAY` folder.
4. Allow Gradle sync to finish (internet is needed to download Android build dependencies).
5. Connect your Android phone with USB debugging enabled, or use an Android emulator.
6. Press **Run ▶** in Android Studio. On first launch, allow the app's audio permission.
7. Put MP3/M4A/OGG/FLAC etc. files in your phone's Music folder (or another indexed audio folder), then tap **SCAN**.

## Notes
- This is Android source code, not a prebuilt APK. It must be built in Android Studio.
- The app queries Android's indexed audio library. Some audio files in the Downloads folder may not be indexed as music; move them to `Music/` or add them through a future file-picker feature if they do not appear.
- Playback is implemented with AndroidX Media3 ExoPlayer. This initial starter keeps the player in the activity, so background playback/lock-screen controls are not yet implemented. For a release-ready version, move playback into a `MediaSessionService`.
- Playlist support beyond the saved Favorites collection is not included in this starter.
- No songs are uploaded; the app reads local files available to it after permission is granted.
